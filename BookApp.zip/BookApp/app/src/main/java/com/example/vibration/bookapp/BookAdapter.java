package com.example.vibration.bookapp;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

/**
 * Created by VibraTion on 5/11/2017.
 */

public class BookAdapter extends ArrayAdapter<AboutBook> {
    public BookAdapter(Context context, ArrayList<AboutBook> aboutBook) {
        super(context, 0, aboutBook);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.book_list, parent, false);
        }
        AboutBook currentBook = getItem(position);
        TextView bookName = (TextView) listItemView.findViewById(R.id.book_name);
        bookName.setText(currentBook.getBookName());
        ImageView image = (ImageView) listItemView.findViewById(R.id.book_image);
        image.setImageBitmap(currentBook.getImage());
        TextView authorName = (TextView) listItemView.findViewById(R.id.author_name);
        authorName.setText(currentBook.getAuthor());
        TextView description = (TextView) listItemView.findViewById(R.id.book_info);
        description.setText(currentBook.getBookInfo());
        return listItemView;
    }
}
