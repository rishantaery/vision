package com.example.vibration.inventoryappv3;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by VibraTion on 5/19/2017.
 */

public class Adapter extends ArrayAdapter<String>  {


    private final Context mContext;

    public Adapter(Context context, ArrayList<String> list) {

        super(context, 0, list);
        this.mContext = context;
    }

    @Override
    public View getView(int position, View convertView, final ViewGroup parent) {

        // Check if an existing view is being reused, otherwise inflate the view
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_item, parent, false);
        }
        final String currentItem = getItem(position);
        TextView itemSet = (TextView) listItemView.findViewById(R.id.name_text_view);
        itemSet.setText(currentItem);
        Button soldItem = (Button) listItemView.findViewById(R.id.sold);
        soldItem.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                final InventoryDbHelper db = new InventoryDbHelper(getContext());
                int pos = currentItem.indexOf("\nQuantity");
                final String itemName = currentItem.substring(0,pos);
                final Cursor cursor = db.getData(itemName);
                if(cursor.moveToFirst()){
                    int quantity = cursor.getInt(cursor.getColumnIndex(InventoryContract.InventoryEntry.COLUMN_QUANTITY));
                    if(quantity > 0)
                    {
                        db.updateData(itemName,quantity,-1);
                        Toast.makeText(getContext(), "Yayy!! Sold",Toast.LENGTH_SHORT).show();
                        if(mContext instanceof MainActivity){
                            ((MainActivity)mContext).refresh();
                        }
                    }
                    else
                    {
                        if(quantity <= 0)
                        {
                            Toast.makeText(getContext(), "No more Items, Order Now",Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });
        TextView setItem = (TextView) listItemView.findViewById(R.id.name_text_view);
        setItem.setText(currentItem);
        return listItemView;
    }
}
