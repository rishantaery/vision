package com.example.vibration.tourguide;

/**
 * Created by VibraTion on 5/4/2017.
 */

public class Info {
    private int mImageResourceId;
    private String mNameOfSpot;
    private String mContactOfSpot;
    private String mAddress;

    public int getImageResourceId() {
        return mImageResourceId;
    }

    public String getNameOfSpot() {
        return mNameOfSpot;
    }

    public String getAddress() {
        return mAddress;
    }

    public String getmContactOfSpot() {
        return mContactOfSpot;
    }

    public Info(String nameOfSpot, String Address, String contact, int imageResourceId) {
        mNameOfSpot = nameOfSpot;
        mAddress = Address;
        mContactOfSpot = contact;
        mImageResourceId = imageResourceId;
    }
}
