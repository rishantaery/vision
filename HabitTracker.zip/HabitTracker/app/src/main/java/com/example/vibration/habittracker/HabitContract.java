package com.example.vibration.habittracker;

import android.provider.BaseColumns;

/**
 * Created by VibraTion on 5/15/2017.
 */

public class HabitContract {
    private HabitContract()
    {
    }
    public static final class HabitEntry implements BaseColumns{
        public final static String TABLE_NAME ="habits";
        public final static String _ID = BaseColumns._ID;
        public final static String COLOUMN_NAME = "name";
        public final static String COLOUMN_GENDER ="gender";
        public final static String COLOUMN_HABIT_JOG = "jog";
        public final static String COLOUMN_HABIT_DRINK_WATER = "drink";
        public static final int GENDER_UNKNOWN=0;
        public static final int GENDER_MALE=1;
        public static final int GENDER_FEMALE=2;
    }
}
