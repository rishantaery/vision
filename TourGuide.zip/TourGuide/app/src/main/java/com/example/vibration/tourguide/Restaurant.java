package com.example.vibration.tourguide;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Created by VibraTion on 5/4/2017.
 */

public class Restaurant extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurants);
        final ArrayList<Info> info = new ArrayList<>();
        info.add(new Info(getString(R.string.mayfair_lagoon), getString(R.string.mayfair_lagoon_add), getString(R.string.mayfair_lagoon_cont), R.drawable.mayfair_lagoon));
        info.add(new Info(getString(R.string.ginger_bhubaneshwar), getString(R.string.ginger_bhubaneshwar_add), getString(R.string.ginger_bhubaneshwar_cont), R.drawable.ginger_bhubaneshwar));
        info.add(new Info(getString(R.string.hotel_pushpak), getString(R.string.hotel_pushpak_add), getString(R.string.hotel_pushpak_cont), R.drawable.hotel_pushpak));
        info.add(new Info(getString(R.string.victoria_club), getString(R.string.victoria_club_add), getString(R.string.victoria_club_cont), R.drawable.victoria_club));
        info.add(new Info(getString(R.string.trident), getString(R.string.trident_add), getString(R.string.trident_cont), R.drawable.trident));
        InfoAdapter adapter = new InfoAdapter(this, info);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);
    }
}
