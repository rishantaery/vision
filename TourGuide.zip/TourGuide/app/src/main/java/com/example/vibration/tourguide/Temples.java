package com.example.vibration.tourguide;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Created by VibraTion on 5/4/2017.
 */

public class Temples extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temple);
        final ArrayList<Info> info = new ArrayList<>();
        info.add(new Info(getString(R.string.dev_kund), getString(R.string.dev_kund_add), getString(R.string.dev_kund_cont), R.drawable.dev_kund));
        info.add(new Info(getString(R.string.jagannath_mandir), getString(R.string.jagannath_mandir_add), getString(R.string.jagannath_mandir_cont), R.drawable.jagannath_mandir));
        info.add(new Info(getString(R.string.sri_sri_mandir), getString(R.string.sri_sri_mandir_add), getString(R.string.sri_sri_mandir_cont), R.drawable.sri_sri_baladev));
        info.add(new Info(getString(R.string.surya_mandir), getString(R.string.surya_mandir_add), getString(R.string.surya_mandir_cont), R.drawable.surya_mandir));
        InfoAdapter adapter = new InfoAdapter(this, info);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);
    }
}
