package com.example.vibration.inventoryappv3;

import android.provider.BaseColumns;

/**
 * Created by VibraTion on 5/19/2017.
 */

public class InventoryContract {

    public static final class InventoryEntry implements BaseColumns {

        public static final String COLUMN_ID = "id";
        public static final String TABLE_NAME = "inventory";
        public static final String COLUMN_PRODUCT_NAME = "name";
        public static final String COLUMN_QUANTITY = "quantity";
        public static final String COLUMN_IMAGE="image";
        public static final String COLUMN_PRICE = "price";
    }
}

