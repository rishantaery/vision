var point = 0; // Starting initializing as 0
var MAX = 450; // supose max score       
var MIN = 150; // suppose min score
var Enemy = function (d, f) { //Enemy function it consists of enemy coming in our path
    this.sprite = 'images/enemy-bug.png';
    this.d = d;
    this.f = f;
    this.speed = this.getSpeed(); // recall function in speed var
};

Enemy.prototype.update = function (dt) { // fy=unction for updation of the enemy
    if (this.d < 500)
        this.d = this.d + this.speed * dt;
    else {
        this.d = -100;
        this.speed = this.getSpeed(); // same as above
    }
};

Enemy.prototype.getSpeed = function () { // function to fetch the speed
    var gs = Math.floor(Math.random() * (MAX - MIN + 1) + MIN); // restore the speed in variable
    return gs;
}

Enemy.prototype.render = function () { // render the enemy onscreen
    ctx.drawImage(Resources.get(this.sprite), this.d, this.f);
};

var Player = function (d, f) { // draw image of a player onscreen
    this.sprite = 'images/char-boy.png';
    this.d = d;
    this.f = f;
};
document.addEventListener('keyup', function (e) { // function consist of all the keys
    var usedKeys = {
        37: 'left',
        38: 'up',
        39: 'right',
        40: 'down',
        65: 'left',
    };
    player.handleInput(usedKeys[e.keyCode]); // keys access by the player
});

Player.prototype.update = function () { //updation in player
    var i; // dec variable
    for (i = 0; i < allEnemies.length; i++) { // for loop
        if ((this.f == allEnemies[i].f) && (this.d < allEnemies[i].d + 101) && (this.d + 101 > allEnemies[i].d)) // checkking all possible conditions
            this.reset(); // reset the position
    }
};

Player.prototype.reset = function () { // reset the position of the player
    this.d = 200;
    this.f = 400;
};

Player.prototype.render = function () { // draw the resources of a player
    ctx.drawImage(Resources.get(this.sprite), this.d, this.f);
}

Player.prototype.handleInput = function (key) { // player function to control keys
    if (key == 'left') { // when player goes left
        if (this.d > 0) this.d -= 100;
    } else if (key == 'right') { //when player goes right
        if (this.d < 400)
            this.d = this.d + 100;
    } else if (key == 'up') { // whwn player goes up
        if (this.f > 40) {
            this.f = this.f - 90;
        } else {
            point = point + 1;
            $('#point').text(point);
            this.reset();
        }
    } else if (key == 'down') { // when player goes down
        if (this.f < 400) {
            this.f = this.f + 90;
        }
    }
};

var allEnemies = [ // consist of all the enemies
new Enemy(0, 40), // enemy1
new Enemy(0, 130), // enemy 2
new Enemy(0, 220), //enemy 3
];
var player = new Player(200, 400); // starting point of a player
