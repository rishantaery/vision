package com.example.vibration.inventoryappv3;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final InventoryDbHelper db = new InventoryDbHelper(this);
        final ListView listView = (ListView) findViewById(R.id.list);
        listView.setEmptyView(findViewById(R.id.empty_text));
        final ArrayList<String> list = db.getAllData();
        Adapter arrayAdapter = new Adapter(MainActivity.this,list);
        listView.setAdapter(arrayAdapter);
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Intent detailIntent = new Intent(MainActivity.this, DetailsActivity.class);
                String itemSelected = list.get(position);
                detailIntent.putExtra("listItem", itemSelected);
                startActivity(detailIntent);
                }
            });

        Button addButton = (Button) findViewById(R.id.add_button);
        addButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view)
            {
                Intent addIntent = new Intent(MainActivity.this, AddProductActivity.class);
                startActivity(addIntent);
            }
        });
        Button refresh = (Button) findViewById(R.id.data_ref);
        refresh.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                final ListView listView = (ListView) findViewById(R.id.list);
                listView.setEmptyView(findViewById(R.id.empty_text));
                ArrayList<String> list = db.getAllData();
                Adapter arrayAdapter = new Adapter(MainActivity.this, list);
                listView.setAdapter(arrayAdapter);
                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        Intent infoIntent = new Intent(MainActivity.this, DetailsActivity.class);
                        String itemSelected = ((TextView) view.findViewById(R.id.name_text_view)).getText().toString();
                        infoIntent.putExtra("listItem", itemSelected);
                        startActivity(infoIntent);
                    }
                });
            }
        });
        Button delete = (Button) findViewById(R.id.delete_all);
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db.deleteAllEntries();
                Toast.makeText(MainActivity.this, "Data Deleted", Toast.LENGTH_SHORT).show();
                refresh();
            }
        });

    }
    public void refresh(){
        Intent intent = new Intent(this,MainActivity.class);
        overridePendingTransition(0, 0);
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        finish();
        overridePendingTransition(0, 0);
        startActivity(intent);
    }
}
