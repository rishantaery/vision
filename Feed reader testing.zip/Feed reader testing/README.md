# Testing Project
* This project is a testing and last project of our nanodegree.

## About Feed Reader
* In this project Jasmine Testing Suite was Used to test for various conditions and functionality of the given feed reader assets provided by udacity.
* This is the final project of udacity's FrontEnd-Nanodegree.
* Resources were tested and new test suites were built according to specifications.
* Finishes testing in 10 seconds (appx).

### How to Load

* Go to github.com/anurag/front-end-nanodegree.
* Then go to Feed Reader and open index.html .
* If all test are up and running no error will be displayed.
