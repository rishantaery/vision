package com.example.vibration.tourguide;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import static java.sql.Types.NULL;

/**
 * Created by VibraTion on 5/4/2017.
 */

public class InfoAdapter extends ArrayAdapter<Info> {
    public InfoAdapter(Activity context, ArrayList<Info> info) {
        super(context, 0, info);
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);
        }
        Info currentInfo = getItem(position);
        if (currentInfo.getmContactOfSpot() != "NA") {
            TextView nameTextView = (TextView) listItemView.findViewById(R.id.name_text_view);
            nameTextView.setText(currentInfo.getNameOfSpot());
            TextView contactTextView = (TextView) listItemView.findViewById(R.id.contact_text_view);
            contactTextView.setText(currentInfo.getmContactOfSpot());
            TextView addressTextView = (TextView) listItemView.findViewById(R.id.address_text_view);
            addressTextView.setText(currentInfo.getAddress());
            ImageView imageView = (ImageView) listItemView.findViewById(R.id.image_view);
            imageView.setImageResource(currentInfo.getImageResourceId());
        } else {
            TextView nameTextView = (TextView) listItemView.findViewById(R.id.name_text_view);
            nameTextView.setText(currentInfo.getNameOfSpot());
            TextView addressTextView = (TextView) listItemView.findViewById(R.id.address_text_view);
            addressTextView.setText(currentInfo.getAddress());
            ImageView imageView = (ImageView) listItemView.findViewById(R.id.image_view);
            imageView.setImageResource(currentInfo.getImageResourceId());
        }
        return listItemView;
    }
}
