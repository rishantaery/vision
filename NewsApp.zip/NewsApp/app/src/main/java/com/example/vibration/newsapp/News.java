package com.example.vibration.newsapp;

/**
 * Created by VibraTion on 5/12/2017.
 */

public class News {
    private String mNewsHeading;
    private String mNewsSection;
    private String mNewsUrl;
    public News(String newsHeading,String newsSection,String newsUrl)
    {
        mNewsHeading = newsHeading;
        mNewsSection = newsSection;
        mNewsUrl = newsUrl;
    }
    public String getmNewsUrl()
    {
        return mNewsUrl;
    }

    public String getmNewsHeading() {
        return mNewsHeading;
    }

    public String getmNewsSection() {
        return mNewsSection;
    }
}
