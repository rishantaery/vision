package com.example.vibration.tourguide;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Created by VibraTion on 5/4/2017.
 */

public class VisitingPlaces extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_places);
        final ArrayList<Info> info = new ArrayList<>();
        info.add(new Info(getString(R.string.dharma_port), getString(R.string.dharma_port_add), getString(R.string.dharma_port_cont), R.drawable.dhamra_port));
        info.add(new Info(getString(R.string.maritime_museum), getString(R.string.maritime_museum_add), getString(R.string.maritime_museum_cont), R.drawable.maritime_museum));
        info.add(new Info(getString(R.string.regional_museum), getString(R.string.regional_museum_add), getString(R.string.regional_museum_cont), R.drawable.regional_museum_of_natural_history));
        info.add(new Info(getString(R.string.sudershan_craft), getString(R.string.sudershan_craft_add), getString(R.string.sudershan_craft_cont), R.drawable.sudershan_craft));
        InfoAdapter adapter = new InfoAdapter(this, info);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);
    }
}