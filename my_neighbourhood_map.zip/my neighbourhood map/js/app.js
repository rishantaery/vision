var map; // declaring a globe variable
var pune_coords = {
    lat: 18.5204, // lat of pune
    lng: 73.8567 // long of pune
}; //pune coordinates
var flag = []; // used for markers 
var detailBox = ''; // using as detail box or information  window
var myMod = {
    list: ko.observableArray([]), //observable knockout list
    searchQuery: ko.observable(), // observable knouckout search
    wasError: ko.observable(false), //observable knocout error
    ErrorMessage: ko.observable(''), //ko err msgg

    const: function () {
        for (var i in flag) {
            myMod.list.push(flag[i].title);
        }
    },

    filter: function (query) { // filter function intead if fun
        myMod.list.removeAll(); // removing the restro on clicking
        for (var i in flag) { // decl for loop
            if (flag[i].title.toLowerCase().indexOf(query.toLowerCase()) > -1) { // check the condition
                myMod.list.push(flag[i].title); // pushing the elements
                flag[i].setVisible(true); // setting the value
            } else {
                flag[i].setVisible(false); //deleting the value
            }
        }
    }
};

function globeErr() {
    myMod.wasError(true); // checing the globe error
    myMod.ErrorMessage('Map unable to open'); // display map unable to open
}

function puneRestro() { // fetching the pune retro
    $.ajax({ // using jquery and asynchronous javascript
        url: 'https://developers.zomato.com/api/v2.1/geocode', // fromzomato url
        headers: { // header of lang and lot
            'Accept': 'application/json', // jquery and json file
            'user-key': 'b5b7a493af627f2e3ac227d4a0705e2c' // user key from zomato api
        },
        data: 'lat=18.5204&lon=73.8567', // long and latitude of pune
        async: true // asynchronous true with ajax
    }).done(function (response) { // checking the response og the map
        var groupData = response.nearby_restaurants; // used as big data
        for (var i in groupData) { // again dec for loop
            var flags = new google.maps.Marker({ // stoting thr google marker in flag
                title: groupData[i].restaurant.name, // fetching the title
                position: { // pune
                    lat: parseFloat(groupData[i].restaurant.location.latitude), // fetching lat
                    lng: parseFloat(groupData[i].restaurant.location.longitude) // fetching long
                },
                map: map, // stoting the original value
                animation: google.maps.Animation.DROP, // animation in the flag
                addres: groupData[i].restaurant.location.address // fetching the adress of pune
            });
            flags.addListener('click', openDetailBox2); // open detailbox 2
            flag.push(flags); // pushe the value of flags or marker
        }
        var bounds = new google.maps.LatLngBounds(); // limitong our area
        for (var k in flag) { // ag and again for loop
            bounds.extend(flag[k].position); // storinh our map limit
        }
        map.fitBounds(bounds); // fitting our map limit
        myMod.const();
    }).fail(function () { // error function
        myMod.wasError(true); // restro set to true
        myMod.ErrorMessage('restaurant cant be diaplayed'); // error in the restro
    });
}

function openDetailBox(flag) { // detail box function
    if (detailBox.flag !== flag && detailBox.flag !== undefined) { // checking the condition
        stopeffectsFlag(detailBox.flag); // stop the effects in the flag or marker
    }
    effectsFlag(flag); // effects in marker
    var content = '<h1>' + flag.title + '</h1>'; // heading in the detail box
    content += '<h2>' + flag.addres + '</h2>'; // address in the detail box
    detailBox.flag = flag; // storing the marker
    detailBox.setContent(content); // setting the address and heading in detail box
    detailBox.open(map, flag); // opening the map
    detailBox.addListener('closeclick', stopeffectsFlag); // stop the effects
}

function openDetailBox2() { // function for 2 detail box
    openDetailBox(this);
}

function effectsFlag(flags) { // effects in the marker
    flags.setIcon('http://maps.google.com/mapfiles/ms/icons/restaurant.png'); // icon for the flag
    flags.setAnimation(google.maps.Animation.BOUNCE); // setting the  animation
}

function stopeffectsFlag(flag) { // stop the effects in flag in marker
    detailBox.flag.setIcon(null); // setting the icon in marker
    detailBox.flag.setAnimation(null); // setting the effects
}

function open(title) { // open func
    for (var i in flag) { // agan declaring variable
        if (flag[i].title == title) { // checking the condition
            openDetailBox(flag[i]); // detail box
            return;
        } // rreturn type
    }
}

function IntialMap() { // initializing the basic structure of map
    detailBox = new google.maps.InfoWindow(); // storing information window in detail box
    map = new google.maps.Map(document.getElementById('map'), { // fecthing through id using jquery
        center: pune_coords, // pune cords
        zoom: 13 // how much zoom in map
    });
    puneRestro(); // rcalling the restro function
}
ko.applyBindings(myMod); // onservable knockout used here
myMod.searchQuery.subscribe(myMod.filter); // the end of knockout
//b5b7a493af627f2e3ac227d4a0705e2c
