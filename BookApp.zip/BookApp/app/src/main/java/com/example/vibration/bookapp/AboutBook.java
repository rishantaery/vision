package com.example.vibration.bookapp;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.widget.ImageView;

/**
 * Created by VibraTion on 5/11/2017.
 */

public class AboutBook {
    private final String mBookName;
    private Bitmap mImage;
    private final String mBookInfo;
    private final String mAuthor;

    public String getAuthor() {
        return mAuthor;
    }

    public String getBookName() {
        return mBookName;
    }

    public Bitmap getImage() {
        return mImage;
    }

    public String getBookInfo() {
        return mBookInfo;
    }

    public AboutBook(String bookName, String author, Bitmap image, String bookInfo) {
        mBookName = bookName;
        mBookInfo = bookInfo;
        mAuthor = author;
        mImage = image;
    }
}
