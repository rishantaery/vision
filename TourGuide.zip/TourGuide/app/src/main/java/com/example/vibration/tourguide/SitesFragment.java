package com.example.vibration.tourguide;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


public class SitesFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View myFragment = inflater.inflate(R.layout.fragment_sites, container, false);
        ImageView restaurants = (ImageView) myFragment.findViewById(R.id.restaurants);
        restaurants.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(), Restaurant.class);
                startActivity(i);
            }
        });
        ImageView visitingPlaces = (ImageView) myFragment.findViewById(R.id.vist_places);
        visitingPlaces.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(), VisitingPlaces.class);
                startActivity(i);
            }
        });
        ImageView temples = (ImageView) myFragment.findViewById(R.id.temples);
        temples.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(), Temples.class);
                startActivity(i);
            }
        });
        ImageView fun = (ImageView) myFragment.findViewById(R.id.fun);
        fun.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(), Fun.class);
                startActivity(i);
            }
        });
        return myFragment;
    }
}
