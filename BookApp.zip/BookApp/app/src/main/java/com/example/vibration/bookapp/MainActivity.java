package com.example.vibration.bookapp;

import android.app.LoaderManager;
import android.content.Context;
import android.content.Loader;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<List<AboutBook>> {
    private static String BOOK_REQUEST_URL;
    private BookAdapter mAdapter;
    private static int BOOK_LOADER_ID = 1;
    private TextView mEmptyStateTextView;
    View loadingIndicator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView bookListView = (ListView) findViewById(R.id.list);
        mAdapter = new BookAdapter(MainActivity.this, new ArrayList<AboutBook>());
        bookListView.setAdapter(mAdapter);
        loadingIndicator = findViewById(R.id.loading_indicator);
        mEmptyStateTextView = (TextView) findViewById(R.id.empty_view);
        bookListView.setEmptyView(mEmptyStateTextView);
        Button mButton = (Button) findViewById(R.id.button);
        ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            android.app.LoaderManager loaderManager = getLoaderManager();
            loaderManager.initLoader(BOOK_LOADER_ID, null, this);
        } else {
            loadingIndicator.setVisibility(View.GONE);
            mEmptyStateTextView.setText(R.string.no_internet_connection);
        }
        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAdapter.clear();
                loadingIndicator.setVisibility(View.VISIBLE);
                mEmptyStateTextView.setVisibility(View.GONE);
                EditText queryBox = (EditText) findViewById(R.id.query_text);
                String query = queryBox.getText().toString().toLowerCase();
                BOOK_REQUEST_URL = "https://www.googleapis.com/books/v1/volumes?q=";
                for (int i = 0; i < query.length(); i++) {
                    if (query.charAt(i) == ' ') {
                        BOOK_REQUEST_URL = BOOK_REQUEST_URL + "%20";
                    } else
                        BOOK_REQUEST_URL = BOOK_REQUEST_URL + query.charAt(i);
                }
                getLoaderManager().restartLoader(BOOK_LOADER_ID, null, MainActivity.this);
            }
        });
    }

    @Override
    public Loader<List<AboutBook>> onCreateLoader(int id, Bundle args) {
        return new BookLoader(this, BOOK_REQUEST_URL);
    }

    @Override
    public void onLoadFinished(Loader<List<AboutBook>> loader, List<AboutBook> data) {
        loadingIndicator.setVisibility(View.GONE);
        mEmptyStateTextView.setText(R.string.no_books);
        mAdapter.clear();
        if (data != null && !data.isEmpty()) {
            mAdapter.addAll(data);
        }
    }

    @Override
    public void onLoaderReset(Loader<List<AboutBook>> loader) {
        mAdapter.clear();
    }
}
