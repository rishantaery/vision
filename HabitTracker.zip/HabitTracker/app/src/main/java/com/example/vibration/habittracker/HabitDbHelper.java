package com.example.vibration.habittracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.vibration.habittracker.HabitContract.HabitEntry;
/**
 * Created by VibraTion on 5/15/2017.
 */

public class HabitDbHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME ="tracker.db";
    private static final int DATABASE_VERSION = 1;
    public HabitDbHelper(Context context)
    {
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String SQL_CREATE_HABITS_TABLE = "CREATE TABLE " +HabitEntry.TABLE_NAME + "(" + HabitEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + HabitEntry.COLOUMN_NAME + " TEXT NOT NULL, "
                + HabitEntry.COLOUMN_GENDER + " TEXT, "
                + HabitEntry.COLOUMN_HABIT_JOG + " TEXT, "
                + HabitEntry.COLOUMN_HABIT_DRINK_WATER + " INTEGER NOT NULL DEFAULT 0);";
        db.execSQL(SQL_CREATE_HABITS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + HabitContract.HabitEntry.TABLE_NAME);
        onCreate(db);
    }
    private void insertHabit(String name,String gender,String jog,int drink){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(HabitEntry.COLOUMN_NAME,name);
        values.put(HabitEntry.COLOUMN_GENDER,gender);
        values.put(HabitEntry.COLOUMN_HABIT_JOG,jog);
        values.put(HabitEntry.COLOUMN_HABIT_DRINK_WATER,drink);
        db.insert(HabitEntry.TABLE_NAME,null,values);
        db.close();
    }
    public Cursor getData(String name)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor result = db.rawQuery("SELECT * FROM " + HabitEntry.TABLE_NAME + " WHERE name = "+name,null);
        db.close();
        return result;
    }
}
