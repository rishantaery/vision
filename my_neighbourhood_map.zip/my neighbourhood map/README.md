# Neighbourhood-Map
This is a single page application featuring a map of neighborhood. Additional functionality to this map includes highlighted locations and third-party data about those locations.

## How to Download
* Download on: https://github/anurag/front-end-nanodegree.
just open repositry and download and you have the map.

## Technical Specification
* KnockoutJS 3
* Google Maps API
* Zomato API

## Instructions
* Run index.html on your favourite browser
