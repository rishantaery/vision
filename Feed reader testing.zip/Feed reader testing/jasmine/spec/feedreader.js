// Feedreader Testuing Project
$(function () {
    describe('RSS Feeds', function () { //  within describe we have a suite
        it('are defined', function () { // with in it we have a specs
            expect(allFeeds).toBeDefined(); // given 
            expect(allFeeds.length).not.toBe(0); // given
        });

        /*Test case 1: Write a test that loops through each feed
           in the allFeeds object and ensures it has a URL defined
           and that the URL is not empty.*/

        it('Defining of url and checking it exists', function () { // spec for 1 test case
            for (var j in allFeeds) { // for in loop
                expect(allFeeds[j].url).not.toEqual(""); //expect that url is non empty
                expect(allFeeds[j].url).not.toBeNull(); // checks url is empty or not
                expect(allFeeds[j].url).toBeDefined(); // checks url is defined in index or not
            }
        });

        it('Name defining and checking there exist a name or not', function () { // spec for name
            for (var j = 0; j < allFeeds.length; j++) { // normal for loop
                expect(allFeeds[j].name).not.toEqual(""); // expects that name is non empty or check it
                expect(allFeeds[j].name).toBeDefined(); // expects name is defined in it or not
            }
        });
    });

    describe('The menu', function () { // Declaring a new suite
        var body = document.body; // store the content of body in body variable
        it('ensures menu element  hidden by default', function () { // specs for tc 2
            expect(body.classList).toContain("menu-hidden"); // it checks or expects that meny is there or not
        });

        var mi = document.querySelector(".menu-icon-link"); // using jquery here to select the menu icon and  store it
        it('Menu changing its  visibilty when menu icon is clicked', // making a new specs
            function () { // function starts
                mi.click(); // mi is menu icon here in test case
                expect(body.classList).not.toContain("menu-hidden"); //checking or expecting On clicking menu hides or not
                mi.click(); // mi is menu icon here in the testcase
                expect(body.classList).toContain("menu-hidden"); // checking or expecting on clicking menu hides  and body class list is used for entire body
            });
    });

    describe('Initial Entries', function () { // making a new suite for test case 3
        beforeEach(function (done) { // as study in the video this syntax is used to check it repeats or not that is reduandancy
            loadFeed(0, function () { // used as array
                done(); // using done function
            });
        });

        it('Consisting of one entry in feed container', function (done) { // making spec for tc 3
            expect($('.feed .entry').length).toBeGreaterThan(0); // this expects or checking that feed conatiner length should gretaer than 0 and it has atleast 1 entry
            done(); // asynchronnnously done function
        });
    });

    describe('New feed Selection', function () { // making anew syute for test case 4
        var old_Feed, new_Feed; // variables for old and new feed
        beforeEach(function (done) { // it uses discussed before above
            loadFeed(0, function () {
                old_Feed = document.querySelector('.feed').innerHTML; // consists of old or purana feed
                loadFeed(1, function () { // array 1
                    new_Feed = document.querySelector('.feed').innerHTML; // consists or have new or naya feed
                    done(); // done as used above
                });
            });
        });

        it('Checking both old_Feed and new_Feed same or not', function (done) { // new specs for tc 4
            expect(old_Feed).not.toEqual(new_Feed); // expecting or checking that both will same or not if the same or not
            done(); // it comes again and agian as its from its name it completes the specs
        });
    });
}());
