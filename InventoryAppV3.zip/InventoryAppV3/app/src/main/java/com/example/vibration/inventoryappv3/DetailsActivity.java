package com.example.vibration.inventoryappv3;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;

/**
 * Created by VibraTion on 5/19/2017.
 */

public class DetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        final InventoryDbHelper db = new InventoryDbHelper(this);
        Intent getList = getIntent();
        String productName = getList.getExtras().getString("listItem");
        int pos = productName.indexOf("\nQuantity");
        final String subProductName = productName.substring(0, pos);

        final Cursor cur = db.getData(subProductName);

        if (cur.moveToFirst()) {
            // Set Product Name
            TextView tName = (TextView)findViewById(R.id.name_text);
            tName.setText(subProductName);
            // Set Price
            int price = cur.getInt(cur.getColumnIndex(InventoryContract.InventoryEntry.COLUMN_PRICE));
            TextView tPrice = (TextView) findViewById(R.id.price_text);
            tPrice.setText("$" + price);
            // Set Quantity
            int quantity = cur.getInt(cur.getColumnIndex(InventoryContract.InventoryEntry.COLUMN_QUANTITY));
            TextView tQuantity = (TextView) findViewById(R.id.quantity_text);
            tQuantity.setText("" + quantity);
            //Image
            ImageView img = (ImageView) findViewById(R.id.image);
            byte[] blob = cur.getBlob(cur.getColumnIndex(InventoryContract.InventoryEntry.COLUMN_IMAGE));
            ByteArrayInputStream inputStream = new ByteArrayInputStream(blob);
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
            img.setImageBitmap(bitmap);
         }
        Button refresh = (Button) findViewById(R.id.refresh_quantity);
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText quantityChange = (EditText) findViewById(R.id.change_quantity);
                String quantityString = quantityChange.getText().toString();
                if(quantityString!=null)
                {
                    int quantityChanges = Integer.parseInt(quantityString);
                    int quantity = cur.getInt(cur.getColumnIndex(InventoryContract.InventoryEntry.COLUMN_QUANTITY));
                    db.updateData(subProductName, quantity, quantityChanges);
                    Intent mainIntent = new Intent(DetailsActivity.this, MainActivity.class);
                    startActivity(mainIntent);
                }
                else
                {
                    Toast.makeText(DetailsActivity.this, "Please Enter a Value to add!", Toast.LENGTH_SHORT).show();
                }

            }
        });
        Button sold = (Button) findViewById(R.id.sold_button_detail);
        sold.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText quantityChange = (EditText) findViewById(R.id.sold_quantity);
                String quantityString = quantityChange.getText().toString();
                if(quantityString!="")
                {
                    quantityString = "-"+quantityString;
                    int quantityChanges = Integer.parseInt(quantityString);
                    int quantityChangesPositive = quantityChanges*-1;
                    int quantity = cur.getInt(cur.getColumnIndex(InventoryContract.InventoryEntry.COLUMN_QUANTITY));
                    if(quantity < quantityChangesPositive)
                        quantityChanges = quantity*-1;
                    db.updateData(subProductName, quantity, quantityChanges);
                    Intent mainIntent = new Intent(DetailsActivity.this, MainActivity.class);
                    startActivity(mainIntent);
                }
                else
                {
                    Toast.makeText(DetailsActivity.this, "Please Enter a Value to Remove!", Toast.LENGTH_SHORT).show();
                }

            }
        });
        // Order Now
        Button order = (Button) findViewById(R.id.order_more);
        order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String productName = "";
                if (cur.moveToFirst()) {
                    productName = cur.getString(cur.getColumnIndex(InventoryContract.InventoryEntry.COLUMN_PRODUCT_NAME));
                }
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("message/rfc822");
                intent.putExtra(Intent.EXTRA_TEXT, "Got An Order for " + productName);
                startActivity(Intent.createChooser(intent, "Send Email"));
            }
        });

        // delete row
        Button delete = (Button) findViewById(R.id.delete_item);
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case DialogInterface.BUTTON_POSITIVE:
                                if (db.deleteData(subProductName)) {
                                    Intent returnHome = new Intent(DetailsActivity.this, MainActivity.class);
                                    startActivity(returnHome);
                                    Toast.makeText(DetailsActivity.this, "Deleted!", Toast.LENGTH_SHORT).show();
                                }
                                break;

                            case DialogInterface.BUTTON_NEGATIVE:
                                break;
                        }
                    }
                };
                AlertDialog.Builder ab = new AlertDialog.Builder(DetailsActivity.this);
                ab.setMessage("Are you sure you want to delete?").setPositiveButton("Yes", dialogClickListener)
                        .setNegativeButton("No", dialogClickListener).show();
            }
        });

    }
}