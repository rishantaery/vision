package com.example.vibration.newsapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by VibraTion on 5/12/2017.
 */

public class NewsAdapter extends ArrayAdapter<News> {
    public NewsAdapter(MainActivity context, ArrayList<News> news)
    {
        super(context,0,news);
    }
    @Override
    public View getView(int positon,View convertView,ViewGroup parent)
    {
        View listItemView = convertView;
        if(listItemView == null)
        {
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.news_list,parent,false);
        }
        News currentNews = getItem(positon);
        TextView newsHeading = (TextView)listItemView.findViewById(R.id.newsHeading);
        newsHeading.setText(currentNews.getmNewsHeading());
        TextView newsSection = (TextView) listItemView.findViewById(R.id.newsSection);
        newsSection.setText(currentNews.getmNewsSection());
        return listItemView;
    }
}
