package com.example.vibration.quizapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void submitAnswer(View view)
    {
        int score = 0;
        RadioButton question1= (RadioButton) findViewById(R.id.correctQ1);
        RadioButton question2= (RadioButton) findViewById(R.id.correctQ2);
        RadioButton question3= (RadioButton) findViewById(R.id.correctQ3);
        RadioButton question4= (RadioButton) findViewById(R.id.correctQ4);
        RadioButton question7= (RadioButton) findViewById(R.id.correctQ7);
        EditText question6 = (EditText) findViewById(R.id.answer6);
        EditText question9 = (EditText) findViewById(R.id.answer9);
        EditText question10 = (EditText) findViewById(R.id.answerTen);
        CheckBox question5choice1 = (CheckBox) findViewById(R.id.correctQ5first);
        CheckBox question5choice2 = (CheckBox) findViewById(R.id.correctQ5second);
        CheckBox question8choice1 = (CheckBox) findViewById(R.id.correctQ8first);
        CheckBox question8choice2 = (CheckBox) findViewById(R.id.correctQ8second);
        CheckBox question8choice3 = (CheckBox) findViewById(R.id.correctQ8third);
        CheckBox wrongChoice1 = (CheckBox) findViewById(R.id.wrongChoice1);
        CheckBox wrongChoice2 = (CheckBox) findViewById(R.id.wrongChoice2);
        CheckBox wrongChoice3 = (CheckBox) findViewById(R.id.wrongChoice3);
        if(question1.isChecked())
        {
            score = score+1;
        }
        if(question2.isChecked())
        {
            score = score+1;
        }
        if(question3.isChecked())
        {
            score = score+1;
        }
        if(question4.isChecked())
        {
            score = score+1;
        }
        if(question7.isChecked())
        {
            score = score+1;
        }
        if(wrongChoice2.isChecked() || wrongChoice3.isChecked())
        {
            score = score+0;
        }
        else
        {

            if (question5choice1.isChecked() && question5choice2.isChecked()) {
                score++;
            }
        }
        if(wrongChoice1.isChecked())
        {
            score = score + 0;
        }
        else
        if(question8choice1.isChecked() && question8choice2.isChecked() && question8choice3.isChecked())
        {
            score++;
        }
        String ans6 = "int array[] = new int[10]";
                String ans9 = "8";
        String ans10 = "sensitive";
        String userans6 = question6.getText().toString();
        String userans10 = question10.getText().toString();
        String l = question9.getText().toString();
        if(ans9.equals(l))
        {
            score++;
        }
        if(userans10.equals(ans10))
        {
            score++;
        }
        if(userans6.equals(ans6))
        {
            score++;
        }
        displayScore(score);
    }
    public void displayScore(int score)
    {
        String finalsScore=Integer.toString(score);
        TextView scoreCard= (TextView) findViewById(R.id.score);
        scoreCard.setText(""+finalsScore);
        Toast toast = Toast.makeText(getApplicationContext(),""+finalsScore,Toast.LENGTH_SHORT);
        toast.show();
    }
}
