var bio = {
    "name": "Anurag Kalyan",
    "role": "Future Web Developer",
    "contacts": {
        "mobile": "09467672114",
        "email": "anurag.kalyan14@gmail.com",
        "github": "anurag.kalyan",
        "twitter": "@anurag.kalyan",
        "location": "PANIPAT"
    },
    "welcomeMessage": "Winter is coming.",
    "skills": ["C", "C++", "HTML", "CSS", "Bootstrap", "JavaScript", "PHP"],
    "biopic": "images/main-qimg-e99e21704560ec3ae528a3ac549effea-c.jpg"
};

bio.display = function() {
    $("#header").prepend(HTMLbioPic.replace("%data%", bio.biopic));
    $("#header").prepend(HTMLheaderName.replace("%data%", bio.name), HTMLheaderRole.replace("%data%", bio.role));
    $("#header").append(HTMLwelcomeMsg.replace("%data%", bio.welcomeMessage));
    formattedContactInfo = [];
    formattedContactInfo.push(HTMLmobile.replace('%data%', bio.contacts.mobile));
    formattedContactInfo.push(HTMLemail.replace('%data%', bio.contacts.email));
    formattedContactInfo.push(HTMLgithub.replace('%data%', bio.contacts.github));
    formattedContactInfo.push(HTMLtwitter.replace('%data%', bio.contacts.twitter));
    formattedContactInfo.push(HTMLlocation.replace('%data%', bio.contacts.location));

    if (bio.skills.length > 0) {
        $("#header").append(HTMLskillsStart);
        for (var avar = 0; avar < bio.skills.length; avar++) {
            $("#skills").append(HTMLskills.replace("%data%", bio.skills[avar]));
        }

    }
    for (var cho in formattedContactInfo) {
        $("#topContacts").append(formattedContactInfo[cho]);
        $("#footerContacts").append(formattedContactInfo[cho]);
    }
};
bio.display();

var education = {
    "schools": [{
            "name": "CHITKARA UNIVERSITY",
            "location": "Rajpura",
            "degree": "BTECH",
            "majors": ["CSE"],
            "dates": "2018",
        },
        {
            "name": "ST. Mary's Convent Sr Sec School",
            "location": "Panipat",
            "degree": "Passed High School",
            "majors": ["Nonmed"],
            "dates": "2013",
        }
    ],
    "onlineCourses": [{
        "title": "FrontEnd Web Developer Nanodegree",
        "School": "Udacity",
        "dates": "2016",
        "url": "https://classroom.udacity.com/nanodegrees/nd001/parts/9d3a4440-1e65-4fc5-9ac1-b40e401ad069"
    }]
};

education.display = function() {
    for (var cho = 0; cho < education.schools.length; cho++) { // in education.schools) {
        $("#education").append(HTMLschoolStart);
        $(".education-entry:last").append(HTMLschoolName.replace("%data%", education.schools[cho].name) +
            HTMLschoolDegree.replace("%data%", education.schools[cho].degree),
            HTMLschoolDates.replace("%data%", education.schools[cho].dates),
            HTMLschoolLocation.replace("%data%", education.schools[cho].location),
            HTMLschoolMajor.replace("%data%", education.schools[cho].majors));
    }

    $("#education").append(HTMLonlineClasses);

    for (var cvar = 0; cvar < education.onlineCourses.length; cvar++) {
        $("#education").append(HTMLschoolStart);
        $(".education-entry:last").append(HTMLonlineTitle.replace("%data%", education.onlineCourses[cvar].title) + HTMLonlineSchool.replace("%data%", education.onlineCourses[cvar].School), HTMLonlineDates.replace("%data%", education.onlineCourses[cvar].dates), HTMLonlineURL.replace("%data%", education.onlineCourses[cvar].url).replace("#", education.onlineCourses[cvar].url));
    }
};
education.display();

var work = {
    "jobs": [{
        "employer": "Chitkara University",
        "title": "Student",
        "dates": "2014-2018",
        "description": "BE in Cse",
        "location": "Rajpura, Punjab"
    }]
};

work.display = function() {

    for (var wvar = 0; wvar < work.jobs.length; wvar++) {
        $("#workExperience").append(HTMLworkStart);

        var formattedEmployer = HTMLworkEmployer.replace("%data%", work.jobs[wvar].employer);
        var formattedTitle = HTMLworkTitle.replace("%data%", work.jobs[wvar].title);
        var formattedEmployerTitle = formattedEmployer + formattedTitle;
        $(".work-entry:last").append(formattedEmployerTitle);

        var formattedDates = HTMLworkDates.replace("%data%", work.jobs[wvar].dates);
        $(".work-entry:last").append(formattedDates);

        var formattedDescription = HTMLworkDescription.replace("%data%", work.jobs[wvar].description);
        $(".work-entry:last").append(formattedDescription);
        var formattedLocation = HTMLworkLocation.replace("%data%", work.jobs[wvar].location);
        $(".work-entry:last").append(formattedLocation);
    }
};
work.display();

var projects = {
    "projects": [{
            "title": "Drink Dispenser",
            "dates": "April-2014",
            "description": "A machine that dispenses desired drink automatically",
            "images": ["images/Drink_dispenser.jpg"]
        },
        {
            "title": "Phone Directory",
            "dates": "May-2016",
            "description": "Can find anyone's number ",
            "images": ["images/phone_direct.jpg"]
        },
    ]
};

projects.display = function() {
    for (var pvar = 0; pvar < projects.projects.length; pvar++) {
        $("#projects").append(HTMLprojectStart);
        $(".project-entry:last").append(HTMLprojectTitle.replace("%data%", projects.projects[pvar].title), HTMLprojectDates.replace("%data%", projects.projects[pvar].dates) + HTMLprojectDescription.replace("%data%", projects.projects[pvar].description));

        if (projects.projects[pvar].images.length > 0) {
            for (var image = 0; image < projects.projects[pvar].images.length; image++)
                $(".project-entry:last").append(HTMLprojectImage.replace("%data%", projects.projects[pvar].images[image]));
        }
    }
};
projects.display();

$(document).click(function(place) {
    var i = place.pageX;
    var j = place.pageY;
    logClicks(i, j);
});

$("#mapDiv").append(googleMap);