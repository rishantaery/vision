package com.example.vibration.tourguide;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Created by VibraTion on 5/4/2017.
 */

public class Fun extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fun);
        final ArrayList<Info> info = new ArrayList<>();
        info.add(new Info(getString(R.string.konark_beach), getString(R.string.konark_beach_add), getString(R.string.konark_beach_cont), R.drawable.konark_beach));
        info.add(new Info(getString(R.string.puri_club), getString(R.string.puri_club_add), getString(R.string.puri_club_cont), R.drawable.puri_club));
        info.add(new Info(getString(R.string.ocean_world_add), getString(R.string.ocean_world_add), getString(R.string.ocean_world_cont), R.drawable.ocean_world_water_park));
        info.add(new Info(getString(R.string.balasore_club), getString(R.string.balasore_club_add), getString(R.string.balasore_club_cont), R.drawable.balasore_club));
        InfoAdapter adapter = new InfoAdapter(this, info);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);
    }
}
