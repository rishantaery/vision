package com.example.vibration.report_card;

/**
 * Created by VibraTion on 4/19/2017.
 */

public class ReportCard {
    private int mChemistryMarks;
    private int mBiologyMarks;
    private int mMathsMarks;
    private int mEnglishMarks;
    private int mPhysicsMarks;
    public ReportCard(int ChemistryMarks,int BiologyMarks,int MathsMarks,int EnglishMarks,int PhysicsMarks )
    {
        mChemistryMarks = ChemistryMarks;
        mBiologyMarks = BiologyMarks;
        mMathsMarks = MathsMarks;
        mEnglishMarks = EnglishMarks;
        mPhysicsMarks = PhysicsMarks;
    }
    public void setChemistryMarks(int chemistryMarks)
    {
    	this.mChemistryMarks = chemistryMarks;
    }
    public void setBiologyMarks(int biologyMarks)
    {
    	this.mBiologyMarks = biologyMarks;
    }
    public void setMathsMarks(int mathsMarks)
    {
    	this.mMathsMarks = mathsMarks;
    }
    public void setEnglishMarks(int englishMarks)
    {
    	this.mEnglishMarks = englishMarks;
    }
    public void setPhysicsMarks(int physicsMarks)
    {
    	this.mPhysicsMarks = physicsMarks;
    }
    public int getChemistryMarks()
    {
        return mChemistryMarks;
    }
    public int getBiologyMarks()
    {
        return mBiologyMarks;
    }
    public int getMathsMarks()
    {
        return mMathsMarks;
    }
    public int getmEnglishMarks()
    {
        return mEnglishMarks;
    }
    public int getPhysicsMarks()
    {
        return mPhysicsMarks;
    }
    public String getChemistryGrades()
    {
        String grade = getGrade(getChemistryMarks());
        return grade;
    }
    public String getBiologyGrades()
    {
        String grade = getGrade(getBiologyMarks());
        return grade;
    }
    public String getMathsGrades()
    {
        String grade = getGrade(getMathsMarks());
        return grade;
    }
    public String getmEnglishGrades()
    {
        String grade = getGrade(getmEnglishMarks());
        return grade;
    }
    public String getPhysicsGrades()
    {
        String grade = getGrade(getPhysicsMarks());
        return grade;
    }
    public String getGrade(int score)
    {
        if(score <= 40)
        {
            return "Fail";
        }
        else
            if(score > 40 && score <= 50)
            {
                return "D";
            }
        else
                if(score > 50 && score <= 70)
                {
                    return "C";
                }
        else
                    if(score > 70 && score <= 85)
                    {
                        return "B";
                    }
        else
                        if(score >85 && score <= 95)
                        {
                            return "A";
                        }
        else
                                return "A+";

    }
    @Override
    public String toString()
    {
        return "Chemistry grade = "+getChemistryGrades()+" Biology Grades = "+getBiologyGrades()+" Maths Grades = "+getMathsGrades()+" English Grades = "+getmEnglishGrades()+ " Physics Marks = "+getPhysicsGrades();
    }
}
